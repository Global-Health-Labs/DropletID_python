#!/usr/bin/env python

## data_gen.py

from Watershed import *

#Watershed.gendata( "broken_rectangle", (300,200), (0,0), 15, "broken_rectangle2.jpg" )

#Watershed.gendata( "triangle", (300,200), (0,0), 45, "triangle2.jpg" )

#Watershed.make_binary_pic_art_nouveau("new_art_from_me")

#Watershed.gendata( "disk", (128,100), (64,50), 30, "disk.jpg" )

#Watershed.gendata( "disk", (40,32), (20,16), 4, "tiny_disk.jpg" )

Watershed.gendata( "twin_rect", (40,32), None, None, "tiny_twin_rect.jpg" )

